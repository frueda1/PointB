exports.graphqlPlugin = require('../lib/next-config/plugins/graphql');
exports.robotsPlugin = require('../lib/next-config/plugins/robots');
exports.sassPlugin = require('../lib/next-config/plugins/sass');
exports.sitemapPlugin = require('../lib/next-config/plugins/sitemap');
