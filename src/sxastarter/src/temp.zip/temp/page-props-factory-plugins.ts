export { componentPropsPlugin } from 'src/lib/page-props-factory/plugins/component-props';
export { errorPagesPlugin } from 'src/lib/page-props-factory/plugins/error-pages';
export { normalModePlugin } from 'src/lib/page-props-factory/plugins/normal-mode';
export { personalizePlugin } from 'src/lib/page-props-factory/plugins/personalize';
export { previewModePlugin } from 'src/lib/page-props-factory/plugins/preview-mode';
